(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-opcao-opcao-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/alert1/alert1.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/alert1/alert1.component.html ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-toolbar>\n  <ion-buttons slot=\"end\">\n    <ion-button (click)=\"closeModal()\">\n      <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\n    </ion-button>\n  </ion-buttons>\n</ion-toolbar>\n<ion-content padding>\n  <div class=\"content\">\n    <p class=\"ion-text-center\"><img style=\"width: 80%;\" src=\"../../assets/16989-team-page.gif\"></p>\n    <p style=\"font-family: lato; font-size: 18px; color: #3E3E3E; \" class=\"ion-text-center\">Agora você receberá dicas por meio de notificações que ajudarão a reduzir as suas dores na face e dos lados da cabeça!</p>\n    <p class=\"ion-text-center\">\n      <ion-chip (click)=\"confirm();\" style=\"background:#3f2e91;\">\n        <ion-icon style=\"color: #ffff;\" name=\"thumbs-up\"></ion-icon>\n        <ion-label style=\"font-family: lato; font-size: 18px; color:#ffff;\">Estou ciente</ion-label>\n      </ion-chip>\n    </p>\n  </div>\n</ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/opcao/opcao.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/opcao/opcao.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n<ion-content padding>\n \n    <div id=\"container\">\n      <h2 style=\"font-family: lato; font-size: 23px; color: #3E3E3E;\" class=\"ion-text-center\">Você precisa dizer os horários em que costuma acordar e dormir.</h2><br><br>\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <p style=\"font-family: lato; font-size: 18px; color: #ed3732; margin-left: 20px; font-weight: bold;\">Acordar\n            </p>\n            <ion-item>\n              <ion-icon style=\"font-size:30px; border: solid 1px; background:#ed3732 ; color:rgb(255, 255, 255);\"\n                name=\"alarm\"></ion-icon>\n              <ion-datetime [(ngModel)]=\"horaAcordar\" placeHolder=\"00:00\" doneText=\"Confirmar\" cancelText=\"Cancelar\"\n                display-format=\"HH:mm\"></ion-datetime>\n            </ion-item>\n          </ion-col>\n          <ion-col>\n            <p style=\"font-family: lato; font-size: 18px; color: #f7ac12; margin-left: 20px; font-weight: bold;\">Dormir\n            </p>\n            <ion-item>\n              <ion-icon style=\"font-size:30px;border: solid 1px; background:#f7ac12 ; color:rgb(255, 255, 255);\"\n                name=\"cloudy-night\"></ion-icon>\n              <ion-datetime [(ngModel)]=\"horaDormir\" placeHolder=\"00:00\" doneText=\"Confirmar\" cancelText=\"Cancelar\"\n                display-format=\"HH:mm\"></ion-datetime>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n  \n    </div>\n    <ion-fab  vertical=\"bottom\" (click)=\"presentModal()\" horizontal=\"center\" slot=\"fixed\">\n      <ion-fab-button class=\"darkblue\">\n        <ion-icon name=\"checkmark\"></ion-icon>\n      </ion-fab-button>\n    </ion-fab>\n\n</ion-content>");

/***/ }),

/***/ "./src/app/alert1/alert1.component.scss":
/*!**********************************************!*\
  !*** ./src/app/alert1/alert1.component.scss ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FsZXJ0MS9hbGVydDEuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/alert1/alert1.component.ts":
/*!********************************************!*\
  !*** ./src/app/alert1/alert1.component.ts ***!
  \********************************************/
/*! exports provided: Alert1Component */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Alert1Component", function() { return Alert1Component; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");




let Alert1Component = class Alert1Component {
    constructor(router, modalController) {
        this.router = router;
        this.modalController = modalController;
    }
    ngOnInit() { }
    confirm() {
        this.router.navigateByUrl("/home1");
        this.modalController.dismiss();
    }
    closeModal() {
        this.modalController.dismiss();
    }
};
Alert1Component.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] }
];
Alert1Component = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-alert1',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./alert1.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/alert1/alert1.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./alert1.component.scss */ "./src/app/alert1/alert1.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]])
], Alert1Component);



/***/ }),

/***/ "./src/app/pages/opcao/opcao-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/opcao/opcao-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: OpcaoPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OpcaoPageRoutingModule", function() { return OpcaoPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _opcao_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./opcao.page */ "./src/app/pages/opcao/opcao.page.ts");




const routes = [
    {
        path: '',
        component: _opcao_page__WEBPACK_IMPORTED_MODULE_3__["OpcaoPage"]
    }
];
let OpcaoPageRoutingModule = class OpcaoPageRoutingModule {
};
OpcaoPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], OpcaoPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/opcao/opcao.module.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/opcao/opcao.module.ts ***!
  \*********************************************/
/*! exports provided: OpcaoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OpcaoPageModule", function() { return OpcaoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _alert1_alert1_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../alert1/alert1.component */ "./src/app/alert1/alert1.component.ts");
/* harmony import */ var _opcao_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./opcao-routing.module */ "./src/app/pages/opcao/opcao-routing.module.ts");
/* harmony import */ var _opcao_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./opcao.page */ "./src/app/pages/opcao/opcao.page.ts");








let OpcaoPageModule = class OpcaoPageModule {
};
OpcaoPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _opcao_routing_module__WEBPACK_IMPORTED_MODULE_6__["OpcaoPageRoutingModule"]
        ],
        declarations: [_opcao_page__WEBPACK_IMPORTED_MODULE_7__["OpcaoPage"], _alert1_alert1_component__WEBPACK_IMPORTED_MODULE_5__["Alert1Component"]],
        entryComponents: [_alert1_alert1_component__WEBPACK_IMPORTED_MODULE_5__["Alert1Component"]]
    })
], OpcaoPageModule);



/***/ }),

/***/ "./src/app/pages/opcao/opcao.page.scss":
/*!*********************************************!*\
  !*** ./src/app/pages/opcao/opcao.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("#container {\n  margin-top: 60px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9yb2RyaWdvL3BhZ2Rvci9zcmMvYXBwL3BhZ2VzL29wY2FvL29wY2FvLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvb3BjYW8vb3BjYW8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUcsZ0JBQUE7QUNBSCIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL29wY2FvL29wY2FvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNjb250YWluZXJ7XG5cbiAgIG1hcmdpbi10b3A6IDYwcHg7XG59IiwiI2NvbnRhaW5lciB7XG4gIG1hcmdpbi10b3A6IDYwcHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/opcao/opcao.page.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/opcao/opcao.page.ts ***!
  \*******************************************/
/*! exports provided: OpcaoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OpcaoPage", function() { return OpcaoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _alert1_alert1_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../alert1/alert1.component */ "./src/app/alert1/alert1.component.ts");
/* harmony import */ var src_app_services_notifications_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/notifications.service */ "./src/app/services/notifications.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);







let OpcaoPage = class OpcaoPage {
    constructor(modalController, notificationService, storage, toastController) {
        this.modalController = modalController;
        this.notificationService = notificationService;
        this.storage = storage;
        this.toastController = toastController;
    }
    ngOnInit() {
    }
    presentModal() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (!this.horaAcordar || !this.horaDormir) {
                this.presentToast('Preencha todos os campos!');
                return;
            }
            const acordar = moment__WEBPACK_IMPORTED_MODULE_6__(this.horaAcordar).format('HH:mm');
            const dormir = moment__WEBPACK_IMPORTED_MODULE_6__(this.horaDormir).format('HH:mm');
            // Verificar diferença de horas
            let a = moment__WEBPACK_IMPORTED_MODULE_6__(`2020/01/01 ${acordar}`);
            let b = moment__WEBPACK_IMPORTED_MODULE_6__(`2020/01/01 ${dormir}`);
            let diffMin = b.diff(a, 'minutes');
            console.log('diffMin', diffMin);
            if (Number(diffMin) < 0) { // Indica que é do outro dia
                a = moment__WEBPACK_IMPORTED_MODULE_6__(`2020/01/01 ${acordar}`);
                b = moment__WEBPACK_IMPORTED_MODULE_6__(`2020/01/02 ${dormir}`);
                diffMin = b.diff(a, 'minutes');
                console.log('diffMin', diffMin);
            }
            if (Number(diffMin) < 360) { // 6 horas
                this.presentToast('Diferença de horas não permitida!');
                return;
            }
            const oldHoraAcordar = yield this.storage.get('notification_hora_acordar');
            const oldHoraDormir = yield this.storage.get('notification_hora_dormir');
            yield this.storage.set('notification_hora_acordar', acordar);
            yield this.storage.set('notification_hora_dormir', dormir);
            yield this.storage.set('notification_diff_min', diffMin);
            // console.log(acordar);
            // console.log(dormir);
            try {
                this.notificationService.verify(oldHoraAcordar, oldHoraDormir);
            }
            catch (e) {
            }
            const modal = yield this.modalController.create({
                component: _alert1_alert1_component__WEBPACK_IMPORTED_MODULE_3__["Alert1Component"],
                swipeToClose: true,
                presentingElement: yield this.modalController.getTop() // Get the top-most ion-modal
            });
            yield modal.present();
        });
    }
    presentToast(msg) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: msg,
                duration: 4000
            });
            toast.present();
        });
    }
};
OpcaoPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: src_app_services_notifications_service__WEBPACK_IMPORTED_MODULE_4__["NotificationsService"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
OpcaoPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-opcao',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./opcao.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/opcao/opcao.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./opcao.page.scss */ "./src/app/pages/opcao/opcao.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
        src_app_services_notifications_service__WEBPACK_IMPORTED_MODULE_4__["NotificationsService"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
], OpcaoPage);



/***/ })

}]);
//# sourceMappingURL=pages-opcao-opcao-module-es2015.js.map