(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-icon-icon-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/icon/icon.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/icon/icon.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<ion-content padding>\n  <br>\n  <br>\n  <h2 style=\"font-family: lato; font-size: 40px; color: rgb(255, 255, 255);\" class=\"ion-text-center\">como você está?</h2>\n  <ion-grid class=\"ion-text-center\">\n    <ion-row>\n      <ion-col id=\"selecticon\" ><img  (click)=\"Semdor()\" style=\"width: 60px;\n          height: 60px;\" src=\"../../assets/icon/Grupo7.png\">\n        <p style=\"font-family: lato; font-size: 17px; color: rgb(255, 255, 255); font-weight: bold;\">Sem dor</p>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid class=\"ion-text-center\">\n    <ion-row>\n      <ion-col id=\"selecticon\"  > <img (click)=\"Incomodo()\" style=\"width: 60px; height: 60px;\" src=\"../../assets/icon/Grupo16.png\">\n        <p style=\"font-family: lato; font-size: 17px; color: rgb(255, 253, 253); font-weight: bold;\">Incômodo</p>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid class=\"ion-text-center\">\n    <ion-row>\n      <ion-col id=\"selecticon\" ><img (click)=\"Comdor()\" style=\"width: 60px; height: 60px;\" src=\"../../assets/icon/Grupo18.png\">\n        <p style=\"font-family: lato; font-size: 17px; color: rgb(255, 255, 255); font-weight: bold;\">Com dor</p>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/icon/icon-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/icon/icon-routing.module.ts ***!
  \***************************************************/
/*! exports provided: IconPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconPageRoutingModule", function() { return IconPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _icon_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./icon.page */ "./src/app/pages/icon/icon.page.ts");




const routes = [
    {
        path: '',
        component: _icon_page__WEBPACK_IMPORTED_MODULE_3__["IconPage"]
    }
];
let IconPageRoutingModule = class IconPageRoutingModule {
};
IconPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], IconPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/icon/icon.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/icon/icon.module.ts ***!
  \*******************************************/
/*! exports provided: IconPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconPageModule", function() { return IconPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _icon_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./icon-routing.module */ "./src/app/pages/icon/icon-routing.module.ts");
/* harmony import */ var _icon_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./icon.page */ "./src/app/pages/icon/icon.page.ts");







let IconPageModule = class IconPageModule {
};
IconPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _icon_routing_module__WEBPACK_IMPORTED_MODULE_5__["IconPageRoutingModule"]
        ],
        declarations: [_icon_page__WEBPACK_IMPORTED_MODULE_6__["IconPage"]]
    })
], IconPageModule);



/***/ }),

/***/ "./src/app/pages/icon/icon.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/icon/icon.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("#selecticon:hover {\n  background-color: #842991;\n}\n\nion-content {\n  --background:#3f2e91 ;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9yb2RyaWdvL3BhZ2Rvci9zcmMvYXBwL3BhZ2VzL2ljb24vaWNvbi5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2ljb24vaWNvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx5QkFBQTtBQ0NKOztBREVBO0VBQ0kscUJBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2ljb24vaWNvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjc2VsZWN0aWNvbjpob3ZlcntcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjODQyOTkxO1xufVxuXG5pb24tY29udGVudHtcbiAgICAtLWJhY2tncm91bmQ6IzNmMmU5MSA7XG59IiwiI3NlbGVjdGljb246aG92ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjODQyOTkxO1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDojM2YyZTkxIDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/icon/icon.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/icon/icon.page.ts ***!
  \*****************************************/
/*! exports provided: IconPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconPage", function() { return IconPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");





1;
let IconPage = class IconPage {
    constructor(storage, alertController, router) {
        this.storage = storage;
        this.alertController = alertController;
        this.router = router;
    }
    ngOnInit() {
    }
    Semdor() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Muito bom!',
                message: 'Vamos acompanha como está a evolução da sua dor',
                buttons: [
                    {
                        text: "Ok",
                        handler: () => {
                            this.addValue(0);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    Incomodo() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Muito bom!',
                message: 'Vamos acompanha como está a evolução da sua dor',
                buttons: [
                    {
                        text: "Ok",
                        handler: () => {
                            this.addValue(50);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    Comdor() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Muito bom!',
                message: 'Vamos acompanha como está a evolução da sua dor',
                buttons: [
                    {
                        text: "Ok",
                        handler: () => {
                            this.addValue(100);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    addValue(val) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let responses = JSON.parse(yield this.storage.get('responses'));
            if (responses === null) {
                const responses_ = [];
                responses_.push({
                    value: val,
                    date: Date.now() // Data atual em milesegundos
                });
                yield this.storage.set('responses', JSON.stringify(responses_));
            }
            else {
                responses.push({
                    value: val,
                    date: Date.now() // Data atual em milesegundos
                });
                yield this.storage.set('responses', JSON.stringify(responses));
            }
            this.router.navigateByUrl("/graficos");
        });
    }
};
IconPage.ctorParameters = () => [
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
IconPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-icon',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./icon.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/icon/icon.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./icon.page.scss */ "./src/app/pages/icon/icon.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
], IconPage);



/***/ })

}]);
//# sourceMappingURL=pages-icon-icon-module-es2015.js.map