(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-home1-home1-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home1/home1.page.html":
  /*!***********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home1/home1.page.html ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesHome1Home1PageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-toolbar>\n  <ion-buttons slot=\"start\">\n    <ion-menu-button></ion-menu-button>\n  </ion-buttons>\n</ion-toolbar>\n<ion-content padding>\n  <p class=\"ion-text-center\"><img src=\"../../../assets/17304-star.gif\"></p>\n  <p class=\"ion-text-center\"> <span style=\"font-family: lato; font-size: 18px; color: #3E3E3E;\"\n      class=\"text-justify\">Pronto! Utilize seu smartphone normalmente. A cada alerta que receber, clique sobre ele e responda como está se\n      sentindo! Depois acompanhe sua evolução no gráfico.</span></p>\n  <p class=\"ion-text-center\">\n    <ion-chip (click)=\"login()\" style=\"background:#3f2e91;\">\n      <ion-icon style=\"color: #ffff;\" name=\"thumbs-up\"></ion-icon>\n      <ion-label style=\"font-family: lato; font-size: 18px; color:#ffff\">OK</ion-label>\n    </ion-chip>\n  </p>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/home1/home1-routing.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/home1/home1-routing.module.ts ***!
    \*****************************************************/

  /*! exports provided: Home1PageRoutingModule */

  /***/
  function srcAppPagesHome1Home1RoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Home1PageRoutingModule", function () {
      return Home1PageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _home1_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./home1.page */
    "./src/app/pages/home1/home1.page.ts");

    const routes = [{
      path: '',
      component: _home1_page__WEBPACK_IMPORTED_MODULE_3__["Home1Page"]
    }];
    let Home1PageRoutingModule = class Home1PageRoutingModule {};
    Home1PageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], Home1PageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/home1/home1.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/pages/home1/home1.module.ts ***!
    \*********************************************/

  /*! exports provided: Home1PageModule */

  /***/
  function srcAppPagesHome1Home1ModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Home1PageModule", function () {
      return Home1PageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _home1_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./home1-routing.module */
    "./src/app/pages/home1/home1-routing.module.ts");
    /* harmony import */


    var _home1_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./home1.page */
    "./src/app/pages/home1/home1.page.ts");

    let Home1PageModule = class Home1PageModule {};
    Home1PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _home1_routing_module__WEBPACK_IMPORTED_MODULE_5__["Home1PageRoutingModule"]],
      declarations: [_home1_page__WEBPACK_IMPORTED_MODULE_6__["Home1Page"]]
    })], Home1PageModule);
    /***/
  },

  /***/
  "./src/app/pages/home1/home1.page.scss":
  /*!*********************************************!*\
    !*** ./src/app/pages/home1/home1.page.scss ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesHome1Home1PageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hvbWUxL2hvbWUxLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/pages/home1/home1.page.ts":
  /*!*******************************************!*\
    !*** ./src/app/pages/home1/home1.page.ts ***!
    \*******************************************/

  /*! exports provided: Home1Page */

  /***/
  function srcAppPagesHome1Home1PageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Home1Page", function () {
      return Home1Page;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    let Home1Page = class Home1Page {
      constructor(router, storage, navCtrl) {
        this.router = router;
        this.storage = storage;
        this.navCtrl = navCtrl;
      }

      ngOnInit() {}

      login() {
        navigator['app'].exitApp();
      }

    };

    Home1Page.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"]
    }, {
      type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]
    }];

    Home1Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-home1',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./home1.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home1/home1.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./home1.page.scss */
      "./src/app/pages/home1/home1.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]])], Home1Page);
    /***/
  }
}]);
//# sourceMappingURL=pages-home1-home1-module-es5.js.map