
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-network-information.Connection",
          "file": "plugins/cordova-plugin-network-information/www/Connection.js",
          "pluginId": "cordova-plugin-network-information",
        "clobbers": [
          "Connection"
        ]
        },
      {
          "id": "cordova-plugin-badge.Badge",
          "file": "plugins/cordova-plugin-badge/www/badge.js",
          "pluginId": "cordova-plugin-badge",
        "clobbers": [
          "cordova.plugins.notification.badge"
        ]
        },
      {
          "id": "cordova-plugin-local-notification.LocalNotification",
          "file": "plugins/cordova-plugin-local-notification/www/local-notification.js",
          "pluginId": "cordova-plugin-local-notification",
        "clobbers": [
          "cordova.plugins.notification.local"
        ]
        },
      {
          "id": "cordova-plugin-device.device",
          "file": "plugins/cordova-plugin-device/www/device.js",
          "pluginId": "cordova-plugin-device",
        "clobbers": [
          "device"
        ]
        },
      {
          "id": "phonegap-plugin-mobile-accessibility.MobileAccessibilityNotifications",
          "file": "plugins/phonegap-plugin-mobile-accessibility/www/MobileAccessibilityNotifications.js",
          "pluginId": "phonegap-plugin-mobile-accessibility",
        "clobbers": [
          "MobileAccessibilityNotifications"
        ]
        },
      {
          "id": "cordova-plugin-network-information.network",
          "file": "plugins/cordova-plugin-network-information/www/network.js",
          "pluginId": "cordova-plugin-network-information",
        "clobbers": [
          "navigator.connection",
          "navigator.network.connection"
        ]
        },
      {
          "id": "onesignal-cordova-plugin.OneSignal",
          "file": "plugins/onesignal-cordova-plugin/www/OneSignal.js",
          "pluginId": "onesignal-cordova-plugin",
        "clobbers": [
          "OneSignal"
        ]
        },
      {
          "id": "cordova-plugin-local-notification.LocalNotification.Core",
          "file": "plugins/cordova-plugin-local-notification/www/local-notification-core.js",
          "pluginId": "cordova-plugin-local-notification",
        "clobbers": [
          "cordova.plugins.notification.local.core",
          "plugin.notification.local.core"
        ]
        },
      {
          "id": "cordova-sqlite-storage.SQLitePlugin",
          "file": "plugins/cordova-sqlite-storage/www/SQLitePlugin.js",
          "pluginId": "cordova-sqlite-storage",
        "clobbers": [
          "SQLitePlugin"
        ]
        },
      {
          "id": "phonegap-plugin-mobile-accessibility.mobile-accessibility",
          "file": "plugins/phonegap-plugin-mobile-accessibility/www/mobile-accessibility.js",
          "pluginId": "phonegap-plugin-mobile-accessibility",
        "clobbers": [
          "window.MobileAccessibility"
        ]
        },
      {
          "id": "com.darktalker.cordova.screenshot.screenshot",
          "file": "plugins/com.darktalker.cordova.screenshot/www/Screenshot.js",
          "pluginId": "com.darktalker.cordova.screenshot",
        "merges": [
          "navigator.screenshot"
        ]
        },
      {
          "id": "cordova-plugin-local-notification.LocalNotification.Util",
          "file": "plugins/cordova-plugin-local-notification/www/local-notification-util.js",
          "pluginId": "cordova-plugin-local-notification",
        "merges": [
          "cordova.plugins.notification.local.core",
          "plugin.notification.local.core"
        ]
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "com.darktalker.cordova.screenshot": "0.1.5",
      "cordova-plugin-badge": "0.8.8",
      "cordova-plugin-device": "2.0.3",
      "cordova-plugin-local-notification": "0.9.0-beta.2",
      "cordova-plugin-network-information": "2.0.3-dev",
      "cordova-sqlite-storage": "5.0.0",
      "onesignal-cordova-plugin": "2.9.0",
      "phonegap-plugin-mobile-accessibility": "1.0.5-dev"
    };
    // BOTTOM OF METADATA
    });
    