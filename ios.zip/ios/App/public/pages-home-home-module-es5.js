(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-home-home-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\n  <ion-slides  id=\"slides\" pager=\"true\" #theSlides [options]=\"slideOpts\">\n    <ion-list>\n      <ion-item *ngFor=\"let n of scheduled\">\n        <ion-label text-wrap>{{ n.id }} - {{n.title}}\n          <p>Trigger: {{ n.trigger | json }}</p>\n        </ion-label>\n      </ion-item>\n    </ion-list>\n    <ion-slide>\n   <div class=\"container-page\">\n    <img style=\"width: 130px; height: 130px;\" src=\"../../../assets/dente.png\">\n    <p  class=\"ion-text-lowercase\" style=\" color:#ffffff; font-size: 20px;\n    font-weight: bold; font-family: Arial, Helvetica, sans-serif;\">\n      <strong> SEJA BEM VINDO! </strong><br>ORI</p>\n      <ion-button (click)=\"next(theSlides)\">Avançar</ion-button>\n   </div>\n    </ion-slide>\n    <ion-slide>\n     <div class=\"container-page\">\n       <img style=\"width: 130px; height: 130px;\" src=\"../../../assets/dental.png\">\n      <p class=\"ion-text-lowercase\" style=\"color:#ffffff; font-size: 20px;\n      font-weight: bold;font-family: Arial, Helvetica, sans-serif;\"><strong>\n        A dor na face e dos lados da cabeça pode estar relacionada a alguns hábitos que sobrecarregam os dentes,\n      </strong><br> ligamentos e músculos da face, da cabeça e do pescoço!</p>\n      <ion-button (click)=\"next(theSlides)\">Avançar</ion-button>\n     </div>\n    </ion-slide>\n    <ion-slide>\n      <div class=\"container-page\">\n        <img style=\"width: 130px; height: 130px;\" src=\"../../../assets/lista-de-controle.png\">\n        <p class=\"ion-text-lowercase\" style=\"color:#ffffff; font-size: 20px;\n        font-weight: bold; margin-bottom: 47px; font-family:  Arial, Helvetica, sans-serif;\"><strong>Estes hábitos são chamados de PARAFUNCIONAIS e estão relacionados</strong><br> a vários fatores, dentre eles a ansiedade e o estresse durante o dia!<br>\n        <ion-button (click)=\"setupPush()\">Confirma</ion-button>\n      </p>\n      </div>\n    </ion-slide>\n\n    </ion-slides>\n</ion-content>\n \n\n\n\n";
    /***/
  },

  /***/
  "./src/app/pages/home/home-routing.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/home/home-routing.module.ts ***!
    \***************************************************/

  /*! exports provided: HomePageRoutingModule */

  /***/
  function srcAppPagesHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
      return HomePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./home.page */
    "./src/app/pages/home/home.page.ts");

    const routes = [{
      path: '',
      component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
    }];
    let HomePageRoutingModule = class HomePageRoutingModule {};
    HomePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], HomePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/home/home.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/pages/home/home.module.ts ***!
    \*******************************************/

  /*! exports provided: HomePageModule */

  /***/
  function srcAppPagesHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
      return HomePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _alert_alert_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../alert/alert.component */
    "./src/app/alert/alert.component.ts");
    /* harmony import */


    var _home_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./home-routing.module */
    "./src/app/pages/home/home-routing.module.ts");
    /* harmony import */


    var _home_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./home.page */
    "./src/app/pages/home/home.page.ts");

    let HomePageModule = class HomePageModule {};
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_6__["HomePageRoutingModule"]],
      declarations: [_home_page__WEBPACK_IMPORTED_MODULE_7__["HomePage"], _alert_alert_component__WEBPACK_IMPORTED_MODULE_5__["AlertComponent"]],
      entryComponents: [_alert_alert_component__WEBPACK_IMPORTED_MODULE_5__["AlertComponent"]]
    })], HomePageModule);
    /***/
  },

  /***/
  "./src/app/pages/home/home.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/pages/home/home.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-slides {\n  height: 100%;\n}\n\nion-content {\n  --background:#3f2e91 ;\n  display: block;\n}\n\nion-button {\n  --background:#fff;\n  --color:#000;\n  --border-color:#fff;\n  width: 7.6rem;\n  --border-style:solid;\n  --border-width:1px;\n  --border-radius:1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9yb2RyaWdvL3BhZ2Rvci9zcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0FDQ0o7O0FEQ0k7RUFDSSxxQkFBQTtFQUNBLGNBQUE7QUNFUjs7QURDSTtFQUNFLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ0VOIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1zbGlkZXMge1xuICAgIGhlaWdodDogMTAwJTtcbiAgfVxuICAgIGlvbi1jb250ZW50e1xuICAgICAgICAtLWJhY2tncm91bmQ6IzNmMmU5MSA7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgIGlvbi1idXR0b257XG4gICAgICAtLWJhY2tncm91bmQ6I2ZmZjtcbiAgICAgIC0tY29sb3I6IzAwMDtcbiAgICAgIC0tYm9yZGVyLWNvbG9yOiNmZmY7XG4gICAgICB3aWR0aDogNy42cmVtO1xuICAgICAgLS1ib3JkZXItc3R5bGU6c29saWQ7XG4gICAgICAtLWJvcmRlci13aWR0aDoxcHg7XG4gICAgICAtLWJvcmRlci1yYWRpdXM6MXB4O1xuICAgIH0iLCJpb24tc2xpZGVzIHtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDojM2YyZTkxIDtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbmlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6I2ZmZjtcbiAgLS1jb2xvcjojMDAwO1xuICAtLWJvcmRlci1jb2xvcjojZmZmO1xuICB3aWR0aDogNy42cmVtO1xuICAtLWJvcmRlci1zdHlsZTpzb2xpZDtcbiAgLS1ib3JkZXItd2lkdGg6MXB4O1xuICAtLWJvcmRlci1yYWRpdXM6MXB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/home/home.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/pages/home/home.page.ts ***!
    \*****************************************/

  /*! exports provided: HomePage */

  /***/
  function srcAppPagesHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePage", function () {
      return HomePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _alert_alert_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../alert/alert.component */
    "./src/app/alert/alert.component.ts");
    /* harmony import */


    var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/local-notifications/ngx */
    "./node_modules/@ionic-native/local-notifications/ngx/index.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_native_onesignal_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/onesignal/ngx */
    "./node_modules/@ionic-native/onesignal/ngx/index.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/ngx/index.js");

    let HomePage = class HomePage {
      constructor(router, oneSignal, alertCtrl, modalController, plt, localNofications, splashScreen, statusBar) {
        this.router = router;
        this.oneSignal = oneSignal;
        this.alertCtrl = alertCtrl;
        this.modalController = modalController;
        this.plt = plt;
        this.localNofications = localNofications;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.slideOpts = {
          on: {
            beforeInit() {
              const swiper = this;
              swiper.classNames.push("".concat(swiper.params.containerModifierClass, "flip"));
              swiper.classNames.push("".concat(swiper.params.containerModifierClass, "3d"));
              const overwriteParams = {
                slidesPerView: 1,
                slidesPerColumn: 1,
                slidesPerGroup: 1,
                watchSlidesProgress: true,
                spaceBetween: 0,
                virtualTranslate: true
              };
              swiper.params = Object.assign(swiper.params, overwriteParams);
              swiper.originalParams = Object.assign(swiper.originalParams, overwriteParams);
            },

            setTranslate() {
              const swiper = this;
              const {
                $,
                slides,
                rtlTranslate: rtl
              } = swiper;

              for (let i = 0; i < slides.length; i += 1) {
                const $slideEl = slides.eq(i);
                let progress = $slideEl[0].progress;

                if (swiper.params.flipEffect.limitRotation) {
                  progress = Math.max(Math.min($slideEl[0].progress, 1), -1);
                }

                const offset$$1 = $slideEl[0].swiperSlideOffset;
                const rotate = -180 * progress;
                let rotateY = rotate;
                let rotateX = 0;
                let tx = -offset$$1;
                let ty = 0;

                if (!swiper.isHorizontal()) {
                  ty = tx;
                  tx = 0;
                  rotateX = -rotateY;
                  rotateY = 0;
                } else if (rtl) {
                  rotateY = -rotateY;
                }

                $slideEl[0].style.zIndex = -Math.abs(Math.round(progress)) + slides.length;

                if (swiper.params.flipEffect.slideShadows) {
                  // Set shadows
                  let shadowBefore = swiper.isHorizontal() ? $slideEl.find('.swiper-slide-shadow-left') : $slideEl.find('.swiper-slide-shadow-top');
                  let shadowAfter = swiper.isHorizontal() ? $slideEl.find('.swiper-slide-shadow-right') : $slideEl.find('.swiper-slide-shadow-bottom');

                  if (shadowBefore.length === 0) {
                    shadowBefore = swiper.$("<div class=\"swiper-slide-shadow-".concat(swiper.isHorizontal() ? 'left' : 'top', "\"></div>"));
                    $slideEl.append(shadowBefore);
                  }

                  if (shadowAfter.length === 0) {
                    shadowAfter = swiper.$("<div class=\"swiper-slide-shadow-".concat(swiper.isHorizontal() ? 'right' : 'bottom', "\"></div>"));
                    $slideEl.append(shadowAfter);
                  }

                  if (shadowBefore.length) shadowBefore[0].style.opacity = Math.max(-progress, 0);
                  if (shadowAfter.length) shadowAfter[0].style.opacity = Math.max(progress, 0);
                }

                $slideEl.transform("translate3d(".concat(tx, "px, ").concat(ty, "px, 0px) rotateX(").concat(rotateX, "deg) rotateY(").concat(rotateY, "deg)"));
              }
            },

            setTransition(duration) {
              const swiper = this;
              const {
                slides,
                activeIndex,
                $wrapperEl
              } = swiper;
              slides.transition(duration).find('.swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left').transition(duration);

              if (swiper.params.virtualTranslate && duration !== 0) {
                let eventTriggered = false; // eslint-disable-next-line

                slides.eq(activeIndex).transitionEnd(function onTransitionEnd() {
                  if (eventTriggered) return;
                  if (!swiper || swiper.destroyed) return;
                  eventTriggered = true;
                  swiper.animating = false;
                  const triggerEvents = ['webkitTransitionEnd', 'transitionend'];

                  for (let i = 0; i < triggerEvents.length; i += 1) {
                    $wrapperEl.trigger(triggerEvents[i]);
                  }
                });
              }
            }

          }
        };
        this.scheduled = [];
        /*
            this.plt.ready().then(() => {
              this.localNofications.on('click').subscribe(res => {
                console.log('click: ', res);
                let msg = res.data ? res.data.mydata : '';
                this.showAlert(res.title, res.text, msg)
              });
        
              this.localNofications.on('trigger').subscribe(res => {
                let msg = res.data ? res.data.mydata : '';
                this.showAlert(res.title, res.text, msg)
              });
        
            });
        */
      }

      initializeApp() {
        this.plt.ready().then(() => {
          this.statusBar.styleDefault();
          this.splashScreen.hide();

          if (this.plt.is('cordova')) {
            this.setupPush();
          }
        });
      }

      presentModal() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
          const modal = yield this.modalController.create({
            component: _alert_alert_component__WEBPACK_IMPORTED_MODULE_3__["AlertComponent"],
            swipeToClose: true,
            presentingElement: yield this.modalController.getTop() // Get the top-most ion-modal

          });
          return yield modal.present();
        });
      }

      setupPush() {
        this.presentModal(); // I recommend to put these into your environment.ts

        this.oneSignal.startInit('44288fb6-2b57-4306-ab35-187d25383f8d', 'ZDJmMDgxYjAtNGZiOC00YTg3LTljODAtZmU5ODQwNjYyYjM2');
        this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.None); // Notifcation was received in general

        this.oneSignal.handleNotificationReceived().subscribe(data => {
          let msg = data.payload.body;
          let title = data.payload.title;
          let additionalData = data.payload.additionalData;
          this.showAlert(title, msg, additionalData.task);
        }); // Notification was really clicked/opened

        this.oneSignal.handleNotificationOpened().subscribe(data => {
          // Just a note that the data is a different place here!
          let additionalData = data.notification.payload.additionalData;
          this.showAlert('Agora nos mostre como você está se sentindo agoras', '!', additionalData.task);
        });
        this.oneSignal.endInit();
      }

      showAlert(title, msg, task) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
          const alert = yield this.alertCtrl.create({
            header: title,
            subHeader: msg,
            buttons: [{
              text: "Vamos la ".concat(task),
              handler: () => {
                this.router.navigateByUrl("/icon");
              }
            }]
          });
          alert.present();
        });
      }

      ngOnInit() {}

      next(slides) {
        console.log(slides);
        slides.slideNext();
      }

    };

    HomePage.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
    }, {
      type: _ionic_native_onesignal_ngx__WEBPACK_IMPORTED_MODULE_6__["OneSignal"]
    }, {
      type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
    }, {
      type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
    }, {
      type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
    }, {
      type: _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_4__["LocalNotifications"]
    }, {
      type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_7__["SplashScreen"]
    }, {
      type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_8__["StatusBar"]
    }];

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('IonSlides', {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonSlides"])], HomePage.prototype, "slides", void 0);
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-home',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./home.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./home.page.scss */
      "./src/app/pages/home/home.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"], _ionic_native_onesignal_ngx__WEBPACK_IMPORTED_MODULE_6__["OneSignal"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"], _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_4__["LocalNotifications"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_7__["SplashScreen"], _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_8__["StatusBar"]])], HomePage);
    /***/
  }
}]);
//# sourceMappingURL=pages-home-home-module-es5.js.map