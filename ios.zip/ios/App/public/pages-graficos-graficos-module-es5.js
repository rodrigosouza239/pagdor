(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-graficos-graficos-module"], {
  /***/
  "./node_modules/chartjs-plugin-annotation/src/annotation.js":
  /*!******************************************************************!*\
    !*** ./node_modules/chartjs-plugin-annotation/src/annotation.js ***!
    \******************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesChartjsPluginAnnotationSrcAnnotationJs(module, exports, __webpack_require__) {
    module.exports = function (Chart) {
      var chartHelpers = Chart.helpers;

      var helpers = __webpack_require__(
      /*! ./helpers.js */
      "./node_modules/chartjs-plugin-annotation/src/helpers.js")(Chart);

      var events = __webpack_require__(
      /*! ./events.js */
      "./node_modules/chartjs-plugin-annotation/src/events.js")(Chart);

      var annotationTypes = Chart.Annotation.types;

      function setAfterDataLimitsHook(axisOptions) {
        helpers.decorate(axisOptions, 'afterDataLimits', function (previous, scale) {
          if (previous) previous(scale);
          helpers.adjustScaleRange(scale);
        });
      }

      function draw(drawTime) {
        return function (chartInstance, easingDecimal) {
          var defaultDrawTime = chartInstance.annotation.options.drawTime;
          helpers.elements(chartInstance).filter(function (element) {
            return drawTime === (element.options.drawTime || defaultDrawTime);
          }).forEach(function (element) {
            element.transition(easingDecimal).draw();
          });
        };
      }

      return {
        beforeInit: function beforeInit(chartInstance) {
          var chartOptions = chartInstance.options; // Initialize chart instance plugin namespace

          var ns = chartInstance.annotation = {
            elements: {},
            options: helpers.initConfig(chartOptions.annotation || {}),
            onDestroy: [],
            firstRun: true,
            supported: false
          }; // Add the annotation scale adjuster to each scale's afterDataLimits hook

          chartInstance.ensureScalesHaveIDs();

          if (chartOptions.scales) {
            ns.supported = true;
            chartHelpers.each(chartOptions.scales.xAxes, setAfterDataLimitsHook);
            chartHelpers.each(chartOptions.scales.yAxes, setAfterDataLimitsHook);
          }
        },
        beforeUpdate: function beforeUpdate(chartInstance) {
          var ns = chartInstance.annotation;

          if (!ns.supported) {
            return;
          }

          if (!ns.firstRun) {
            ns.options = helpers.initConfig(chartInstance.options.annotation || {});
          } else {
            ns.firstRun = false;
          }

          var elementIds = []; // Add new elements, or update existing ones

          ns.options.annotations.forEach(function (annotation) {
            var id = annotation.id || helpers.objectId(); // No element with that ID exists, and it's a valid annotation type

            if (!ns.elements[id] && annotationTypes[annotation.type]) {
              var cls = annotationTypes[annotation.type];
              var element = new cls({
                id: id,
                options: annotation,
                chartInstance: chartInstance
              });
              element.initialize();
              ns.elements[id] = element;
              annotation.id = id;
              elementIds.push(id);
            } else if (ns.elements[id]) {
              // Nothing to do for update, since the element config references
              // the same object that exists in the chart annotation config
              elementIds.push(id);
            }
          }); // Delete removed elements

          Object.keys(ns.elements).forEach(function (id) {
            if (elementIds.indexOf(id) === -1) {
              ns.elements[id].destroy();
              delete ns.elements[id];
            }
          });
        },
        afterScaleUpdate: function afterScaleUpdate(chartInstance) {
          helpers.elements(chartInstance).forEach(function (element) {
            element.configure();
          });
        },
        beforeDatasetsDraw: draw('beforeDatasetsDraw'),
        afterDatasetsDraw: draw('afterDatasetsDraw'),
        afterDraw: draw('afterDraw'),
        afterInit: function afterInit(chartInstance) {
          // Detect and intercept events that happen on an annotation element
          var watchFor = chartInstance.annotation.options.events;

          if (chartHelpers.isArray(watchFor) && watchFor.length > 0) {
            var canvas = chartInstance.chart.canvas;
            var eventHandler = events.dispatcher.bind(chartInstance);
            events.collapseHoverEvents(watchFor).forEach(function (eventName) {
              chartHelpers.addEvent(canvas, eventName, eventHandler);
              chartInstance.annotation.onDestroy.push(function () {
                chartHelpers.removeEvent(canvas, eventName, eventHandler);
              });
            });
          }
        },
        destroy: function destroy(chartInstance) {
          var deregisterers = chartInstance.annotation.onDestroy;

          while (deregisterers.length > 0) {
            deregisterers.pop()();
          }
        }
      };
    };
    /***/

  },

  /***/
  "./node_modules/chartjs-plugin-annotation/src/element.js":
  /*!***************************************************************!*\
    !*** ./node_modules/chartjs-plugin-annotation/src/element.js ***!
    \***************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesChartjsPluginAnnotationSrcElementJs(module, exports) {
    module.exports = function (Chart) {
      var chartHelpers = Chart.helpers;
      var AnnotationElement = Chart.Element.extend({
        initialize: function initialize() {
          this.hidden = false;
          this.hovering = false;
          this._model = chartHelpers.clone(this._model) || {};
          this.setDataLimits();
        },
        destroy: function destroy() {},
        setDataLimits: function setDataLimits() {},
        configure: function configure() {},
        inRange: function inRange() {},
        getCenterPoint: function getCenterPoint() {},
        getWidth: function getWidth() {},
        getHeight: function getHeight() {},
        getArea: function getArea() {},
        draw: function draw() {}
      });
      return AnnotationElement;
    };
    /***/

  },

  /***/
  "./node_modules/chartjs-plugin-annotation/src/events.js":
  /*!**************************************************************!*\
    !*** ./node_modules/chartjs-plugin-annotation/src/events.js ***!
    \**************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesChartjsPluginAnnotationSrcEventsJs(module, exports, __webpack_require__) {
    module.exports = function (Chart) {
      var chartHelpers = Chart.helpers;

      var helpers = __webpack_require__(
      /*! ./helpers.js */
      "./node_modules/chartjs-plugin-annotation/src/helpers.js")(Chart);

      function collapseHoverEvents(events) {
        var hover = false;
        var filteredEvents = events.filter(function (eventName) {
          switch (eventName) {
            case 'mouseenter':
            case 'mouseover':
            case 'mouseout':
            case 'mouseleave':
              hover = true;
              return false;

            default:
              return true;
          }
        });

        if (hover && filteredEvents.indexOf('mousemove') === -1) {
          filteredEvents.push('mousemove');
        }

        return filteredEvents;
      }

      function dispatcher(e) {
        var ns = this.annotation;
        var elements = helpers.elements(this);
        var position = chartHelpers.getRelativePosition(e, this.chart);
        var element = helpers.getNearestItems(elements, position);
        var events = collapseHoverEvents(ns.options.events);
        var dblClickSpeed = ns.options.dblClickSpeed;
        var eventHandlers = [];
        var eventHandlerName = helpers.getEventHandlerName(e.type);
        var options = (element || {}).options; // Detect hover events

        if (e.type === 'mousemove') {
          if (element && !element.hovering) {
            // hover started
            ['mouseenter', 'mouseover'].forEach(function (eventName) {
              var eventHandlerName = helpers.getEventHandlerName(eventName);
              var hoverEvent = helpers.createMouseEvent(eventName, e); // recreate the event to match the handler

              element.hovering = true;

              if (typeof options[eventHandlerName] === 'function') {
                eventHandlers.push([options[eventHandlerName], hoverEvent, element]);
              }
            });
          } else if (!element) {
            // hover ended
            elements.forEach(function (element) {
              if (element.hovering) {
                element.hovering = false;
                var options = element.options;
                ['mouseout', 'mouseleave'].forEach(function (eventName) {
                  var eventHandlerName = helpers.getEventHandlerName(eventName);
                  var hoverEvent = helpers.createMouseEvent(eventName, e); // recreate the event to match the handler

                  if (typeof options[eventHandlerName] === 'function') {
                    eventHandlers.push([options[eventHandlerName], hoverEvent, element]);
                  }
                });
              }
            });
          }
        } // Suppress duplicate click events during a double click
        // 1. click -> 2. click -> 3. dblclick
        //
        // 1: wait dblClickSpeed ms, then fire click
        // 2: cancel (1) if it is waiting then wait dblClickSpeed ms then fire click, else fire click immediately
        // 3: cancel (1) or (2) if waiting, then fire dblclick 


        if (element && events.indexOf('dblclick') > -1 && typeof options.onDblclick === 'function') {
          if (e.type === 'click' && typeof options.onClick === 'function') {
            clearTimeout(element.clickTimeout);
            element.clickTimeout = setTimeout(function () {
              delete element.clickTimeout;
              options.onClick.call(element, e);
            }, dblClickSpeed);
            e.stopImmediatePropagation();
            e.preventDefault();
            return;
          } else if (e.type === 'dblclick' && element.clickTimeout) {
            clearTimeout(element.clickTimeout);
            delete element.clickTimeout;
          }
        } // Dispatch the event to the usual handler, but only if we haven't substituted it


        if (element && typeof options[eventHandlerName] === 'function' && eventHandlers.length === 0) {
          eventHandlers.push([options[eventHandlerName], e, element]);
        }

        if (eventHandlers.length > 0) {
          e.stopImmediatePropagation();
          e.preventDefault();
          eventHandlers.forEach(function (eventHandler) {
            // [handler, event, element]
            eventHandler[0].call(eventHandler[2], eventHandler[1]);
          });
        }
      }

      return {
        dispatcher: dispatcher,
        collapseHoverEvents: collapseHoverEvents
      };
    };
    /***/

  },

  /***/
  "./node_modules/chartjs-plugin-annotation/src/helpers.js":
  /*!***************************************************************!*\
    !*** ./node_modules/chartjs-plugin-annotation/src/helpers.js ***!
    \***************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesChartjsPluginAnnotationSrcHelpersJs(module, exports) {
    function noop() {}

    function elements(chartInstance) {
      // Turn the elements object into an array of elements
      var elements = chartInstance.annotation.elements;
      return Object.keys(elements).map(function (id) {
        return elements[id];
      });
    }

    function objectId() {
      return Math.random().toString(36).substr(2, 6);
    }

    function isValid(rawValue) {
      if (rawValue === null || typeof rawValue === 'undefined') {
        return false;
      } else if (typeof rawValue === 'number') {
        return isFinite(rawValue);
      } else {
        return !!rawValue;
      }
    }

    function decorate(obj, prop, func) {
      var prefix = '$';

      if (!obj[prefix + prop]) {
        if (obj[prop]) {
          obj[prefix + prop] = obj[prop].bind(obj);

          obj[prop] = function () {
            var args = [obj[prefix + prop]].concat(Array.prototype.slice.call(arguments));
            return func.apply(obj, args);
          };
        } else {
          obj[prop] = function () {
            var args = [undefined].concat(Array.prototype.slice.call(arguments));
            return func.apply(obj, args);
          };
        }
      }
    }

    function callEach(fns, method) {
      fns.forEach(function (fn) {
        (method ? fn[method] : fn)();
      });
    }

    function getEventHandlerName(eventName) {
      return 'on' + eventName[0].toUpperCase() + eventName.substring(1);
    }

    function createMouseEvent(type, previousEvent) {
      try {
        return new MouseEvent(type, previousEvent);
      } catch (exception) {
        try {
          var m = document.createEvent('MouseEvent');
          m.initMouseEvent(type, previousEvent.canBubble, previousEvent.cancelable, previousEvent.view, previousEvent.detail, previousEvent.screenX, previousEvent.screenY, previousEvent.clientX, previousEvent.clientY, previousEvent.ctrlKey, previousEvent.altKey, previousEvent.shiftKey, previousEvent.metaKey, previousEvent.button, previousEvent.relatedTarget);
          return m;
        } catch (exception2) {
          var e = document.createEvent('Event');
          e.initEvent(type, previousEvent.canBubble, previousEvent.cancelable);
          return e;
        }
      }
    }

    module.exports = function (Chart) {
      var chartHelpers = Chart.helpers;

      function initConfig(config) {
        config = chartHelpers.configMerge(Chart.Annotation.defaults, config);

        if (chartHelpers.isArray(config.annotations)) {
          config.annotations.forEach(function (annotation) {
            annotation.label = chartHelpers.configMerge(Chart.Annotation.labelDefaults, annotation.label);
          });
        }

        return config;
      }

      function getScaleLimits(scaleId, annotations, scaleMin, scaleMax) {
        var ranges = annotations.filter(function (annotation) {
          return !!annotation._model.ranges[scaleId];
        }).map(function (annotation) {
          return annotation._model.ranges[scaleId];
        });
        var min = ranges.map(function (range) {
          return Number(range.min);
        }).reduce(function (a, b) {
          return isFinite(b) && !isNaN(b) && b < a ? b : a;
        }, scaleMin);
        var max = ranges.map(function (range) {
          return Number(range.max);
        }).reduce(function (a, b) {
          return isFinite(b) && !isNaN(b) && b > a ? b : a;
        }, scaleMax);
        return {
          min: min,
          max: max
        };
      }

      function adjustScaleRange(scale) {
        // Adjust the scale range to include annotation values
        var range = getScaleLimits(scale.id, elements(scale.chart), scale.min, scale.max);

        if (typeof scale.options.ticks.min === 'undefined' && typeof scale.options.ticks.suggestedMin === 'undefined') {
          scale.min = range.min;
        }

        if (typeof scale.options.ticks.max === 'undefined' && typeof scale.options.ticks.suggestedMax === 'undefined') {
          scale.max = range.max;
        }

        if (scale.handleTickRangeOptions) {
          scale.handleTickRangeOptions();
        }
      }

      function getNearestItems(annotations, position) {
        var minDistance = Number.POSITIVE_INFINITY;
        return annotations.filter(function (element) {
          return element.inRange(position.x, position.y);
        }).reduce(function (nearestItems, element) {
          var center = element.getCenterPoint();
          var distance = chartHelpers.distanceBetweenPoints(position, center);

          if (distance < minDistance) {
            nearestItems = [element];
            minDistance = distance;
          } else if (distance === minDistance) {
            // Can have multiple items at the same distance in which case we sort by size
            nearestItems.push(element);
          }

          return nearestItems;
        }, []).sort(function (a, b) {
          // If there are multiple elements equally close,
          // sort them by size, then by index
          var sizeA = a.getArea(),
              sizeB = b.getArea();
          return sizeA > sizeB || sizeA < sizeB ? sizeA - sizeB : a._index - b._index;
        }).slice(0, 1)[0]; // return only the top item
      }

      return {
        initConfig: initConfig,
        elements: elements,
        callEach: callEach,
        noop: noop,
        objectId: objectId,
        isValid: isValid,
        decorate: decorate,
        adjustScaleRange: adjustScaleRange,
        getNearestItems: getNearestItems,
        getEventHandlerName: getEventHandlerName,
        createMouseEvent: createMouseEvent
      };
    };
    /***/

  },

  /***/
  "./node_modules/chartjs-plugin-annotation/src/index.js":
  /*!*************************************************************!*\
    !*** ./node_modules/chartjs-plugin-annotation/src/index.js ***!
    \*************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesChartjsPluginAnnotationSrcIndexJs(module, exports, __webpack_require__) {
    // Get the chart variable
    var Chart = __webpack_require__(
    /*! chart.js */
    "./node_modules/chart.js/dist/Chart.js");

    Chart = typeof Chart === 'function' ? Chart : window.Chart; // Configure plugin namespace

    Chart.Annotation = Chart.Annotation || {};
    Chart.Annotation.drawTimeOptions = {
      afterDraw: 'afterDraw',
      afterDatasetsDraw: 'afterDatasetsDraw',
      beforeDatasetsDraw: 'beforeDatasetsDraw'
    };
    Chart.Annotation.defaults = {
      drawTime: 'afterDatasetsDraw',
      dblClickSpeed: 350,
      // ms
      events: [],
      annotations: []
    };
    Chart.Annotation.labelDefaults = {
      backgroundColor: 'rgba(0,0,0,0.8)',
      fontFamily: Chart.defaults.global.defaultFontFamily,
      fontSize: Chart.defaults.global.defaultFontSize,
      fontStyle: 'bold',
      fontColor: '#fff',
      xPadding: 6,
      yPadding: 6,
      cornerRadius: 6,
      position: 'center',
      xAdjust: 0,
      yAdjust: 0,
      enabled: false,
      content: null
    };
    Chart.Annotation.Element = __webpack_require__(
    /*! ./element.js */
    "./node_modules/chartjs-plugin-annotation/src/element.js")(Chart);
    Chart.Annotation.types = {
      line: __webpack_require__(
      /*! ./types/line.js */
      "./node_modules/chartjs-plugin-annotation/src/types/line.js")(Chart),
      box: __webpack_require__(
      /*! ./types/box.js */
      "./node_modules/chartjs-plugin-annotation/src/types/box.js")(Chart)
    };

    var annotationPlugin = __webpack_require__(
    /*! ./annotation.js */
    "./node_modules/chartjs-plugin-annotation/src/annotation.js")(Chart);

    module.exports = annotationPlugin;
    Chart.pluginService.register(annotationPlugin);
    /***/
  },

  /***/
  "./node_modules/chartjs-plugin-annotation/src/types/box.js":
  /*!*****************************************************************!*\
    !*** ./node_modules/chartjs-plugin-annotation/src/types/box.js ***!
    \*****************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesChartjsPluginAnnotationSrcTypesBoxJs(module, exports, __webpack_require__) {
    // Box Annotation implementation
    module.exports = function (Chart) {
      var helpers = __webpack_require__(
      /*! ../helpers.js */
      "./node_modules/chartjs-plugin-annotation/src/helpers.js")(Chart);

      var BoxAnnotation = Chart.Annotation.Element.extend({
        setDataLimits: function setDataLimits() {
          var model = this._model;
          var options = this.options;
          var chartInstance = this.chartInstance;
          var xScale = chartInstance.scales[options.xScaleID];
          var yScale = chartInstance.scales[options.yScaleID];
          var chartArea = chartInstance.chartArea; // Set the data range for this annotation

          model.ranges = {};

          if (!chartArea) {
            return;
          }

          var min = 0;
          var max = 0;

          if (xScale) {
            min = helpers.isValid(options.xMin) ? options.xMin : xScale.getPixelForValue(chartArea.left);
            max = helpers.isValid(options.xMax) ? options.xMax : xScale.getPixelForValue(chartArea.right);
            model.ranges[options.xScaleID] = {
              min: Math.min(min, max),
              max: Math.max(min, max)
            };
          }

          if (yScale) {
            min = helpers.isValid(options.yMin) ? options.yMin : yScale.getPixelForValue(chartArea.bottom);
            max = helpers.isValid(options.yMax) ? options.yMax : yScale.getPixelForValue(chartArea.top);
            model.ranges[options.yScaleID] = {
              min: Math.min(min, max),
              max: Math.max(min, max)
            };
          }
        },
        configure: function configure() {
          var model = this._model;
          var options = this.options;
          var chartInstance = this.chartInstance;
          var xScale = chartInstance.scales[options.xScaleID];
          var yScale = chartInstance.scales[options.yScaleID];
          var chartArea = chartInstance.chartArea; // clip annotations to the chart area

          model.clip = {
            x1: chartArea.left,
            x2: chartArea.right,
            y1: chartArea.top,
            y2: chartArea.bottom
          };
          var left = chartArea.left,
              top = chartArea.top,
              right = chartArea.right,
              bottom = chartArea.bottom;
          var min, max;

          if (xScale) {
            min = helpers.isValid(options.xMin) ? xScale.getPixelForValue(options.xMin) : chartArea.left;
            max = helpers.isValid(options.xMax) ? xScale.getPixelForValue(options.xMax) : chartArea.right;
            left = Math.min(min, max);
            right = Math.max(min, max);
          }

          if (yScale) {
            min = helpers.isValid(options.yMin) ? yScale.getPixelForValue(options.yMin) : chartArea.bottom;
            max = helpers.isValid(options.yMax) ? yScale.getPixelForValue(options.yMax) : chartArea.top;
            top = Math.min(min, max);
            bottom = Math.max(min, max);
          } // Ensure model has rect coordinates


          model.left = left;
          model.top = top;
          model.right = right;
          model.bottom = bottom; // Stylistic options

          model.borderColor = options.borderColor;
          model.borderWidth = options.borderWidth;
          model.backgroundColor = options.backgroundColor;
        },
        inRange: function inRange(mouseX, mouseY) {
          var model = this._model;
          return model && mouseX >= model.left && mouseX <= model.right && mouseY >= model.top && mouseY <= model.bottom;
        },
        getCenterPoint: function getCenterPoint() {
          var model = this._model;
          return {
            x: (model.right + model.left) / 2,
            y: (model.bottom + model.top) / 2
          };
        },
        getWidth: function getWidth() {
          var model = this._model;
          return Math.abs(model.right - model.left);
        },
        getHeight: function getHeight() {
          var model = this._model;
          return Math.abs(model.bottom - model.top);
        },
        getArea: function getArea() {
          return this.getWidth() * this.getHeight();
        },
        draw: function draw() {
          var view = this._view;
          var ctx = this.chartInstance.chart.ctx;
          ctx.save(); // Canvas setup

          ctx.beginPath();
          ctx.rect(view.clip.x1, view.clip.y1, view.clip.x2 - view.clip.x1, view.clip.y2 - view.clip.y1);
          ctx.clip();
          ctx.lineWidth = view.borderWidth;
          ctx.strokeStyle = view.borderColor;
          ctx.fillStyle = view.backgroundColor; // Draw

          var width = view.right - view.left,
              height = view.bottom - view.top;
          ctx.fillRect(view.left, view.top, width, height);
          ctx.strokeRect(view.left, view.top, width, height);
          ctx.restore();
        }
      });
      return BoxAnnotation;
    };
    /***/

  },

  /***/
  "./node_modules/chartjs-plugin-annotation/src/types/line.js":
  /*!******************************************************************!*\
    !*** ./node_modules/chartjs-plugin-annotation/src/types/line.js ***!
    \******************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesChartjsPluginAnnotationSrcTypesLineJs(module, exports, __webpack_require__) {
    // Line Annotation implementation
    module.exports = function (Chart) {
      var chartHelpers = Chart.helpers;

      var helpers = __webpack_require__(
      /*! ../helpers.js */
      "./node_modules/chartjs-plugin-annotation/src/helpers.js")(Chart);

      var horizontalKeyword = 'horizontal';
      var verticalKeyword = 'vertical';
      var LineAnnotation = Chart.Annotation.Element.extend({
        setDataLimits: function setDataLimits() {
          var model = this._model;
          var options = this.options; // Set the data range for this annotation

          model.ranges = {};
          model.ranges[options.scaleID] = {
            min: options.value,
            max: options.endValue || options.value
          };
        },
        configure: function configure() {
          var model = this._model;
          var options = this.options;
          var chartInstance = this.chartInstance;
          var ctx = chartInstance.chart.ctx;
          var scale = chartInstance.scales[options.scaleID];
          var pixel, endPixel;

          if (scale) {
            pixel = helpers.isValid(options.value) ? scale.getPixelForValue(options.value) : NaN;
            endPixel = helpers.isValid(options.endValue) ? scale.getPixelForValue(options.endValue) : pixel;
          }

          if (isNaN(pixel)) {
            return;
          }

          var chartArea = chartInstance.chartArea; // clip annotations to the chart area

          model.clip = {
            x1: chartArea.left,
            x2: chartArea.right,
            y1: chartArea.top,
            y2: chartArea.bottom
          };

          if (this.options.mode == horizontalKeyword) {
            model.x1 = chartArea.left;
            model.x2 = chartArea.right;
            model.y1 = pixel;
            model.y2 = endPixel;
          } else {
            model.y1 = chartArea.top;
            model.y2 = chartArea.bottom;
            model.x1 = pixel;
            model.x2 = endPixel;
          }

          model.line = new LineFunction(model);
          model.mode = options.mode; // Figure out the label:

          model.labelBackgroundColor = options.label.backgroundColor;
          model.labelFontFamily = options.label.fontFamily;
          model.labelFontSize = options.label.fontSize;
          model.labelFontStyle = options.label.fontStyle;
          model.labelFontColor = options.label.fontColor;
          model.labelXPadding = options.label.xPadding;
          model.labelYPadding = options.label.yPadding;
          model.labelCornerRadius = options.label.cornerRadius;
          model.labelPosition = options.label.position;
          model.labelXAdjust = options.label.xAdjust;
          model.labelYAdjust = options.label.yAdjust;
          model.labelEnabled = options.label.enabled;
          model.labelContent = options.label.content;
          ctx.font = chartHelpers.fontString(model.labelFontSize, model.labelFontStyle, model.labelFontFamily);
          var textWidth = ctx.measureText(model.labelContent).width;
          var textHeight = ctx.measureText('M').width;
          var labelPosition = calculateLabelPosition(model, textWidth, textHeight, model.labelXPadding, model.labelYPadding);
          model.labelX = labelPosition.x - model.labelXPadding;
          model.labelY = labelPosition.y - model.labelYPadding;
          model.labelWidth = textWidth + 2 * model.labelXPadding;
          model.labelHeight = textHeight + 2 * model.labelYPadding;
          model.borderColor = options.borderColor;
          model.borderWidth = options.borderWidth;
          model.borderDash = options.borderDash || [];
          model.borderDashOffset = options.borderDashOffset || 0;
        },
        inRange: function inRange(mouseX, mouseY) {
          var model = this._model;
          return (// On the line
            model.line && model.line.intersects(mouseX, mouseY, this.getHeight()) || // On the label
            model.labelEnabled && model.labelContent && mouseX >= model.labelX && mouseX <= model.labelX + model.labelWidth && mouseY >= model.labelY && mouseY <= model.labelY + model.labelHeight
          );
        },
        getCenterPoint: function getCenterPoint() {
          return {
            x: (this._model.x2 + this._model.x1) / 2,
            y: (this._model.y2 + this._model.y1) / 2
          };
        },
        getWidth: function getWidth() {
          return Math.abs(this._model.right - this._model.left);
        },
        getHeight: function getHeight() {
          return this._model.borderWidth || 1;
        },
        getArea: function getArea() {
          return Math.sqrt(Math.pow(this.getWidth(), 2) + Math.pow(this.getHeight(), 2));
        },
        draw: function draw() {
          var view = this._view;
          var ctx = this.chartInstance.chart.ctx;

          if (!view.clip) {
            return;
          }

          ctx.save(); // Canvas setup

          ctx.beginPath();
          ctx.rect(view.clip.x1, view.clip.y1, view.clip.x2 - view.clip.x1, view.clip.y2 - view.clip.y1);
          ctx.clip();
          ctx.lineWidth = view.borderWidth;
          ctx.strokeStyle = view.borderColor;

          if (ctx.setLineDash) {
            ctx.setLineDash(view.borderDash);
          }

          ctx.lineDashOffset = view.borderDashOffset; // Draw

          ctx.beginPath();
          ctx.moveTo(view.x1, view.y1);
          ctx.lineTo(view.x2, view.y2);
          ctx.stroke();

          if (view.labelEnabled && view.labelContent) {
            ctx.beginPath();
            ctx.rect(view.clip.x1, view.clip.y1, view.clip.x2 - view.clip.x1, view.clip.y2 - view.clip.y1);
            ctx.clip();
            ctx.fillStyle = view.labelBackgroundColor; // Draw the tooltip

            chartHelpers.drawRoundedRectangle(ctx, view.labelX, // x
            view.labelY, // y
            view.labelWidth, // width
            view.labelHeight, // height
            view.labelCornerRadius // radius
            );
            ctx.fill(); // Draw the text

            ctx.font = chartHelpers.fontString(view.labelFontSize, view.labelFontStyle, view.labelFontFamily);
            ctx.fillStyle = view.labelFontColor;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(view.labelContent, view.labelX + view.labelWidth / 2, view.labelY + view.labelHeight / 2);
          }

          ctx.restore();
        }
      });

      function LineFunction(view) {
        // Describe the line in slope-intercept form (y = mx + b).
        // Note that the axes are rotated 90° CCW, which causes the
        // x- and y-axes to be swapped.
        var m = (view.x2 - view.x1) / (view.y2 - view.y1);
        var b = view.x1 || 0;
        this.m = m;
        this.b = b;

        this.getX = function (y) {
          // Coordinates are relative to the origin of the canvas
          return m * (y - view.y1) + b;
        };

        this.getY = function (x) {
          return (x - b) / m + view.y1;
        };

        this.intersects = function (x, y, epsilon) {
          epsilon = epsilon || 0.001;
          var dy = this.getY(x),
              dx = this.getX(y);
          return (!isFinite(dy) || Math.abs(y - dy) < epsilon) && (!isFinite(dx) || Math.abs(x - dx) < epsilon);
        };
      }

      function calculateLabelPosition(view, width, height, padWidth, padHeight) {
        var line = view.line;
        var ret = {},
            xa = 0,
            ya = 0;

        switch (true) {
          // top align
          case view.mode == verticalKeyword && view.labelPosition == "top":
            ya = padHeight + view.labelYAdjust;
            xa = width / 2 + view.labelXAdjust;
            ret.y = view.y1 + ya;
            ret.x = (isFinite(line.m) ? line.getX(ret.y) : view.x1) - xa;
            break;
          // bottom align

          case view.mode == verticalKeyword && view.labelPosition == "bottom":
            ya = height + padHeight + view.labelYAdjust;
            xa = width / 2 + view.labelXAdjust;
            ret.y = view.y2 - ya;
            ret.x = (isFinite(line.m) ? line.getX(ret.y) : view.x1) - xa;
            break;
          // left align

          case view.mode == horizontalKeyword && view.labelPosition == "left":
            xa = padWidth + view.labelXAdjust;
            ya = -(height / 2) + view.labelYAdjust;
            ret.x = view.x1 + xa;
            ret.y = line.getY(ret.x) + ya;
            break;
          // right align

          case view.mode == horizontalKeyword && view.labelPosition == "right":
            xa = width + padWidth + view.labelXAdjust;
            ya = -(height / 2) + view.labelYAdjust;
            ret.x = view.x2 - xa;
            ret.y = line.getY(ret.x) + ya;
            break;
          // center align

          default:
            ret.x = (view.x1 + view.x2 - width) / 2 + view.labelXAdjust;
            ret.y = (view.y1 + view.y2 - height) / 2 + view.labelYAdjust;
        }

        return ret;
      }

      return LineAnnotation;
    };
    /***/

  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/graficos/graficos.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/graficos/graficos.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesGraficosGraficosPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-toolbar>\n  <ion-buttons (click)=\"logout()\" slot=\"end\">\n    <ion-icon style=\"font-size: 30px; color: #3f2e91;\" name=\"close\"></ion-icon>\n  </ion-buttons>\n</ion-toolbar>\n<ion-content class=\"state\"><br><br>\n  <ion-card-content><canvas height=\"300x\" *ngIf=\"lineChartData\" baseChart [datasets]=\"lineChartData\"\n      [labels]=\"lineChartLabels\" [options]=\"lineChartOptions\" [plugins]=\"lineChartPlugins\" [legend]=\"lineChartLegend\"\n      [chartType]=\"lineChartType\" [colors]=\"colorChart\"></canvas>\n    </ion-card-content>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/graficos/graficos-routing.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/graficos/graficos-routing.module.ts ***!
    \***********************************************************/

  /*! exports provided: GraficosPageRoutingModule */

  /***/
  function srcAppPagesGraficosGraficosRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GraficosPageRoutingModule", function () {
      return GraficosPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _graficos_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./graficos.page */
    "./src/app/pages/graficos/graficos.page.ts");

    const routes = [{
      path: '',
      component: _graficos_page__WEBPACK_IMPORTED_MODULE_3__["GraficosPage"]
    }];
    let GraficosPageRoutingModule = class GraficosPageRoutingModule {};
    GraficosPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], GraficosPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/graficos/graficos.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/graficos/graficos.module.ts ***!
    \***************************************************/

  /*! exports provided: GraficosPageModule */

  /***/
  function srcAppPagesGraficosGraficosModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GraficosPageModule", function () {
      return GraficosPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _graficos_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./graficos-routing.module */
    "./src/app/pages/graficos/graficos-routing.module.ts");
    /* harmony import */


    var _graficos_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./graficos.page */
    "./src/app/pages/graficos/graficos.page.ts");
    /* harmony import */


    var ng2_charts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ng2-charts */
    "./node_modules/ng2-charts/fesm2015/ng2-charts.js");

    let GraficosPageModule = class GraficosPageModule {};
    GraficosPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], ng2_charts__WEBPACK_IMPORTED_MODULE_7__["ChartsModule"], _graficos_routing_module__WEBPACK_IMPORTED_MODULE_5__["GraficosPageRoutingModule"]],
      declarations: [_graficos_page__WEBPACK_IMPORTED_MODULE_6__["GraficosPage"]]
    })], GraficosPageModule);
    /***/
  },

  /***/
  "./src/app/pages/graficos/graficos.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/pages/graficos/graficos.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesGraficosGraficosPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "img {\n  border: 5px solid #365454;\n  width: 70%;\n  margin-top: 3em;\n}\n\n.newBG {\n  background: #4C6E6E !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9yb2RyaWdvL3BhZ2Rvci9zcmMvYXBwL3BhZ2VzL2dyYWZpY29zL2dyYWZpY29zLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvZ3JhZmljb3MvZ3JhZmljb3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUlBO0VBQ0kseUJBQUE7RUFDQSxVQUFBO0VBQ0EsZUFBQTtBQ0hKOztBRE1BO0VBQ0ksOEJBQUE7QUNISiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2dyYWZpY29zL2dyYWZpY29zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xuICAgXG59XG5cbmltZyB7XG4gICAgYm9yZGVyOiA1cHggc29saWQgIzM2NTQ1NDtcbiAgICB3aWR0aDo3MCU7XG4gICAgbWFyZ2luLXRvcDogM2VtXG59XG5cbi5uZXdCRyB7XG4gICAgYmFja2dyb3VuZDojNEM2RTZFICFpbXBvcnRhbnQ7XG59IiwiaW1nIHtcbiAgYm9yZGVyOiA1cHggc29saWQgIzM2NTQ1NDtcbiAgd2lkdGg6IDcwJTtcbiAgbWFyZ2luLXRvcDogM2VtO1xufVxuXG4ubmV3Qkcge1xuICBiYWNrZ3JvdW5kOiAjNEM2RTZFICFpbXBvcnRhbnQ7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pages/graficos/graficos.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/pages/graficos/graficos.page.ts ***!
    \*************************************************/

  /*! exports provided: GraficosPage */

  /***/
  function srcAppPagesGraficosGraficosPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GraficosPage", function () {
      return GraficosPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
    /* harmony import */


    var chartjs_plugin_annotation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! chartjs-plugin-annotation */
    "./node_modules/chartjs-plugin-annotation/src/index.js");
    /* harmony import */


    var chartjs_plugin_annotation__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(chartjs_plugin_annotation__WEBPACK_IMPORTED_MODULE_3__);
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_native_screenshot_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/screenshot/ngx */
    "./node_modules/@ionic-native/screenshot/ngx/index.js");

    let GraficosPage = class GraficosPage {
      constructor(storage, router, screenshot) {
        this.storage = storage;
        this.router = router;
        this.screenshot = screenshot;
        this.state = false;
        this.responses = [];
        this.lineChartLabels = [];
        this.lineChartType = 'line';
        this.lineChartLegend = true;
        this.lineChartPlugins = [];
        this.barChartLegend = true;
        this.barChartPlugins = [chartjs_plugin_annotation__WEBPACK_IMPORTED_MODULE_3__];
        this.colorChart = [{
          backgroundColor: 'rgb(0, 178, 255)',
          borderColor: 'rgb(100,149,237)',
          pointBackgroundColor: 'rgb(0, 178, 255)',
          pointBorderColor: '#fff',
          pointHoverBackgroundColor: '#fff',
          pointHoverBorderColor: 'rgb(0, 178, 255)'
        }];
        this.lineChartOptions = {
          elements: {
            line: {
              tension: 0,
              fill: false
            }
          },
          scales: {
            yAxes: [{
              scaleLabel: {
                display: true,
                labelString: 'Acompanha sua dor em porcentagem'
              },
              ticks: {
                beginAtZero: true,
                max: 100,
                min: 0,
                stepSize: 50,
                callback: function callback(value, index, values) {
                  return value + '%';
                }
              }
            }]
          },
          tooltips: {
            enabled: false
          },
          annotation: {
            annotations: [{
              type: 'line',
              mode: 'horizontal',
              scaleID: 'y-axis-0',
              value: '0',
              borderColor: 'green',
              borderWidth: 1
            }, {
              type: 'line',
              mode: 'horizontal',
              scaleID: 'y-axis-0',
              value: '50',
              borderColor: 'gray',
              borderWidth: 1
            }, {
              type: 'line',
              mode: 'horizontal',
              scaleID: 'y-axis-0',
              value: '100',
              borderColor: 'red',
              borderWidth: 2
            }]
          }
        };
      }

      ngOnInit() {}

      myRandom(min, max, multiple) {
        return Math.round(Math.random() * (max - min) / multiple) * multiple + min;
      }

      reset() {
        var self = this;
        setTimeout(function () {
          self.state = false;
        }, 1000);
      }

      screenShot() {
        this.screenshot.save('jpg', 80, 'myscreenshot.jpg').then(res => {
          this.screen = res.filePath;
          this.state = true;
          this.reset();
        });
      }

      ngAfterViewInit() {
        setTimeout(() => {
          this.getLineChart();
        }, 150);
      }

      getLineChart() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
          this.responses = JSON.parse((yield this.storage.get('responses')));
          let responses = [];

          for (let i = 0; i < this.responses.length; i++) {
            this.lineChartLabels.push(i + 1 + "ª");
            responses.push(this.responses[i].value);
          }

          this.lineChartData = [{
            data: responses,
            label: 'Acompanhe a evolução da sua dor'
          }];
        });
      }

      confirm() {
        this.router.navigateByUrl("/home");
      }

      logout() {
        navigator['app'].exitApp();
      }

    };

    GraficosPage.ctorParameters = () => [{
      type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
    }, {
      type: _ionic_native_screenshot_ngx__WEBPACK_IMPORTED_MODULE_5__["Screenshot"]
    }];

    GraficosPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-graficos',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./graficos.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/graficos/graficos.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./graficos.page.scss */
      "./src/app/pages/graficos/graficos.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"], _ionic_native_screenshot_ngx__WEBPACK_IMPORTED_MODULE_5__["Screenshot"]])], GraficosPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-graficos-graficos-module-es5.js.map